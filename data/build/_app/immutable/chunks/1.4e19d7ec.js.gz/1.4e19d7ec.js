import{default as t}from"../entry/_error.svelte.32ddb04d.js";export{t as component};
