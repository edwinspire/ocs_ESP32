import{default as t}from"../entry/_page.svelte.99359e14.js";export{t as component};
