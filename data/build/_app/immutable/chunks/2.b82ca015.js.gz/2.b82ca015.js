import{default as t}from"../entry/_page.svelte.142d0c3a.js";export{t as component};
