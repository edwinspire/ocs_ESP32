import{default as t}from"../entry/_error.svelte.4cfff072.js";export{t as component};
