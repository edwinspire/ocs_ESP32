import{_ as r}from"./_layout.4039aba4.js";import{default as t}from"../entry/_layout.svelte.a2e57f0c.js";export{t as component,r as universal};
